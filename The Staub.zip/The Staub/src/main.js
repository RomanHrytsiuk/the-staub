function closeVideo() {
  const videoModal = document.getElementById('videoModal');
  const iframe = videoModal.querySelector('.video__iframe');
  iframe.src = '';
  videoModal.style.display = 'none';
}

const closeButton = document.querySelector('.close-button');
const videoPlayButton = document.querySelector('.video__play-button');
const body = document.querySelector('body');

body.addEventListener('click', (event) => {
  closeVideo();
})

videoPlayButton.addEventListener('click', (event) => {
  event.stopPropagation();
  playVideo();
})

closeButton.addEventListener('click', (event) => {
  event.stopPropagation();
  closeVideo()
})

const subscribeButton = document.querySelector('.subscribe__button');

function subscribe() {
  const emailInput = document.getElementById('touch');
  const isEmailValid = emailInput.checkValidity();
  const button = document.getElementById('subscribe__button');

  if (!isEmailValid) {
    emailInput.focus();

    const errorMessage = document.createElement('p');
    errorMessage.textContent = 'This field is required';
    errorMessage.style.color = 'red';
    errorMessage.id = 'errorMessage';

    const errorMessageExist = document.getElementById('errorMessage');
    const divMessage = document.querySelector('.errorMessage-container');
    divMessage.style.display = 'block';

    if (errorMessageExist) {
      existingErrorMessage.remove();
    }

    divMessage.parentElement.appendChild(errorMessage);

    emailInput.addEventListener('focusout', () => {
      errorMessage.remove();
      divMessage.style.display = 'none';
    });

    return;
  }

  const subscribeButton = document.querySelector('.subscribe__button');
  const inputContainer = document.querySelector('.input__container');
  subscribeButton.remove();
  inputContainer.remove();

  const subscribeMessage = document.getElementById('subscribeMessage');
  subscribeMessage.style.display = 'block';
}

subscribeButton.addEventListener('click', () => {
  subscribe();
})

const appButton = document.querySelector('.footer__app-button');
const googleButton = document.querySelector('.footer__google-button');
const checkPriceButton = document.querySelector('.about__button');
const cookWareButton1 = document.querySelector('.cookware__button1');
const cookWareButton2 = document.querySelector('.cookware__button2');
const cookWareButton3 = document.querySelector('.cookware__button3');
const protectionkitButton1 = document.querySelector('.protectionkit__button1');
const rotectionkitButton2 = document.querySelector('.protectionkit__button2');
const rotectionkitButton3 = document.querySelector('.protectionkit__button3');

appButton.addEventListener('click', () => {
  window.open('https://www.apple.com/ua/', '_blank')
})

googleButton.addEventListener('click', () => {
  window.open('https://play.google.com/store/games?device=windows', '_blank')
})

checkPriceButton.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/', '_blank')
})

cookWareButton1.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/section:menyu/snidanki/', '_blank')
})

cookWareButton2.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/section:menyu/starteri/', '_blank')
})

cookWareButton3.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/section:menyu/salati/', '_blank')
})

protectionkitButton1.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/section:menyu/snidanki/', '_blank')
})

protectionkitButton2.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/section:menyu/starteri/', '_blank')
})

protectionkitButton3.addEventListener('click', () => {
  window.open('https://redpepper.choiceqr.com/section:menyu/salati/', '_blank')
})

function playVideo() {
  document.getElementById('videoModal').style.display = 'flex';
  const iframe = videoModal.querySelector('.video__iframe');
  iframe.src = "https://www.youtube.com/embed/edm4V2Tg8fE?autoplay=1";
}
